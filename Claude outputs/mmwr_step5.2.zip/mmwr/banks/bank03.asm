;Mega Man: Dr. Wily's Revenge disassembly - ROM bank $03
;Section layout ported from the iimarckus/megaman skeleton; all labels are this
;project's own. Confidence tags: [ok] verified here, [dc] corroborated by Data
;Crystal, [?] unverified guess. See docs/CONVENTIONS.md.

SECTION "bank3",ROMX[$4000],BANK[$3]
Func_03_4000:
	jp $55db

Func_03_4003:
	jp $57cf

Func_03_4006:
	jp $5982

Func_03_4009:
	jp $5b5f

Func_03_400C:
	jp $5cac

Func_03_400F:
	jp $6b49

Func_03_4012:
	jp $6d19

Func_03_4015:
	jp $6de7

Func_03_4018:
	jp $6ed9

Func_03_401B:
	jp $72e1

Func_03_401E:
	jp $7491

Func_03_4021:
	jp $757b

Func_03_4024:
	jp $4744

Func_03_4027:
	jp $52cd

Func_03_402A:
	jp $4d5b

Func_03_402D:
	jp $512c

Func_03_4030:
	jp $5e79

Func_03_4033:
	jp $62cc

Func_03_4036:
	jp $6537

Func_03_4039:
	jp $69a3

Func_03_403C:
	jp $769f

Func_03_403F:
	jp $796b

DEF OBJBANK EQUS "_03"
;The object library, shared with banks $03, $09 and $0D (step 5.2).	;[ok]
SECTION "Object Library 03", ROMX[$4042], BANK[$3]
include "engine/object_library.asm"
PURGE OBJBANK

SECTION "Bank 3 Objects", ROMX[$4744], BANK[$3]
INCBIN "baserom.gb",$C744,$FBE5-$C744

	freespace $FBE5
