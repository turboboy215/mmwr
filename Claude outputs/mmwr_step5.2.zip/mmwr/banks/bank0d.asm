;Mega Man: Dr. Wily's Revenge disassembly - ROM bank $0D
;Section layout ported from the iimarckus/megaman skeleton; all labels are this
;project's own. Confidence tags: [ok] verified here, [dc] corroborated by Data
;Crystal, [?] unverified guess. See docs/CONVENTIONS.md.

SECTION "bankD",ROMX[$4000],BANK[$D]

Entry_0D_4000:
	jp $48d9

Entry_0D_4003:
	jp $4dc9

Entry_0D_4006:
	jp $4f06

Entry_0D_4009:
	jp $50af

Entry_0D_400C:
	jp $51bb

Entry_0D_400F:
	jp $5a76

Entry_0D_4012:
	jp $5ec2

Entry_0D_4015:
	jp $61c3

Entry_0D_4018:
	jp $625c

DEF OBJBANK EQUS "_0D"
;The object library, shared with banks $03, $09 and $0D (step 5.2).	;[ok]
SECTION "Object Library 0D", ROMX[$401B], BANK[$D]
include "engine/object_library.asm"
PURGE OBJBANK

SECTION "Bank D Objects", ROMX[$471D], BANK[$D]
INCBIN "baserom.gb",$3471D,$36311-$3471D

	freespace $36311
