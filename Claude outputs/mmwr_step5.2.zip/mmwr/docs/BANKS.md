# Bank map and banking architecture

256 KB, 16 banks of 16 KB, MBC1, no cartridge RAM, DMG-only (no SGB or CGB support).

## How banking works

The game uses an unusually tidy scheme, which is good news: most banked code is
reachable only through a small, fixed entry table at the top of its bank.

* **`$DF99` — current bank shadow.** Every bank switch goes through the two-instruction
  idiom captured by the `bankswitch` macro: write A to `$DF99`, then to `$2100`.
  117 sites in the ROM, and **111 of them are in bank `$00`**. Banks `$0B`, `$0C` and
  `$0E` switch on their own only to return to bank `$01`.
* **Bank `$01` is the default resident bank.** Code that switches away restores `$01`
  when it is done.
* **`$DF9A` — selected audio bank.** Written only with `$02` or `$0A`, from banks
  `$00`, `$01`, `$0B` and `$0E` (24 sites). It exists because the music and SFX data
  did not fit in one bank, so the driver is duplicated in both and the caller picks.
* **`rst $08` → `FarCallAudio` (`$02AD`) is the audio far-call trampoline.** `$0008`
  is `jp FarCallAudio`. It stashes A/L/H/E/D in `hFarCallA`–`hFarCallD`
  (`$FF8C`–`$FF90`), pages in `wAudioBank`, reads the target from the `dw` inline
  after the `rst`, pushes `.restoreBank1` and then the target, reloads the registers
  and `ret`s into the target.

  The seven stubs at **`$0236`–`$024A`** are each `rst $08` + `dw`, targeting
  `$4000`, `$4003` … `$4012` — the seven `jp` entries at the top of both audio banks.
  They are now named `AudioInit`, `AudioCondSoundOff`, `AudioLoadSound`,
  `AudioLoadSong`, `AudioGetSlot`, `AudioPlay`, `AudioSFXOff`.

  *Resolved:* an earlier reading of this suggested tail-call semantics, because the
  trampoline discards the `rst` return address. It does not behave that way. Callers
  reach the audio API with `call AudioLoadSong`, i.e. they `call` the *stub*, and the
  stub executes the `rst`. The discarded address is the stub-internal one; the
  caller's own return address is still on the stack underneath, and `.restoreBank1`'s
  `ret` pops it. So these are ordinary calls that happen to cross a bank boundary,
  and they come back with bank `$01` paged in. Flags and BC pass through untouched.

* **`CallBank1Routine` (`$01F4`) is the general trampoline**, for everything that is
  not audio. Index in A selects from a seven-entry table at `$0228` that mixes ROM0
  and bank `$01` targets. It saves `wCurrentBank`, pages in bank `$01`, calls, then
  restores. The call is made through a three-byte `jp` that the routine *assembles
  into WRAM* at `$C0D0` each time, rather than through a jump table — one for the
  efficiency tally in Phase 6.

## Bank entry tables

Every banked bank except `$01` and `$0F` opens with a fixed dispatch table. This is
the complete public API surface of the ROM, and naming these entries is the single
highest-leverage piece of work available.

| Bank | Entry table at `$4000` | Content |
|---|---|---|
| `$00` | — (ROM0) | reset/interrupt vectors, main loop, OAM, joypad, RNG, bank switching, audio thunks |
| `$01` | `InstallWeaponHooks`: `call` / `call` / `ret` | **100% source (step 5.1).** The resident bank: Mega Man (movement, collision, drawing), his weapons and shots, items, explosions, the pause menu, the HUD, the title, stage-select and weapon-get screens |
| `$02` | 7 × `jp` | **audio engine + music/SFX set A — 100% disassembled** |
| `$03` | 22 × `jp` | object code (22 types); the shared object library (`$4042`) is source since step 5.2 |
| `$04` | 42 × `dw` | sprite graphics (Mega Man, weapons, items, HUD, 7-segment digits) |
| `$05` | 4 × `dw` | the four robot master stages - format in `docs/LEVELS.md` (step 4.1), with a little per-stage code (frame hooks: conveyors, spikes, ice, palette effects, behind-BG zones) |
| `$06` | 21 × `dw` | tilemaps (title screen identified) |
| `$07` | 31 × `dw` | **100% source (step 4.4).** Sprite tiles for object types 30-56 (robot masters, Wily bosses, castle objects; `gfx/bosses/`) and the stage select's robot master sprites (tile lists, metasprite frames, jump arcs) |
| `$08` | 4 × `dw` | **100% source (step 4.3).** The Wily castle - Wily 1, Wily 2's teleporter hub and five boss rooms, Wily 3 and the Wily Machine room - plus an unreferenced test stage and the unused alternate Fire Man stage; `docs/LEVELS.md` |
| `$09` | 24 × `jp` | **100% source (step 5.2).** Object code: the shared object library and 24 object types (Enker, Bubble Man, Flash Man, Heat Man and their shots, the boss door, the Atomic Fire block, 14 enemies) |
| `$0A` | 7 × `jp` | **music/SFX set B — 100% disassembled** |
| `$0B` | 1 × `jp` + init | copies `$17` bytes from `$401C` to `$C0B0`; 10.5 KB of the bank is empty |
| `$0C` | 8 × `dw`, then `jp` × 2 | stage background tilesets (one per stage), and the password screens (entry `$4010`, display `$4013`) — step 3.3 |
| `$0D` | 9 × `jp` | object code (9 types, including the Wily Machine); the shared object library (`$401B`) is source since step 5.2; 7.2 KB empty |
| `$0E` | 1 × `jp` + init | same init idiom as `$0B` |
| `$0F` | — | **completely empty ($FF × 16384)** |

## Bank `$01` (step 5.1)

Bank `$01` has no entry table because it does not need one: it is paged in
whenever nothing else is, so bank `$00` simply `call`s into it (about 30 sites,
all by name now). The other ways in are `CallBank1Routine` indexes 1, 2 and 4
(`SpawnExplosionBurst`, `SpawnDeathExplosion`, `SpawnExplosion`), the two RAM
hooks it installs at `$4000` (`wHookA` = `TryFireWeapon`, called by
`UpdatePlayer`; `wHookB` = `UpdateShots`, called by `StageFrameLoop`), the
`jp`s in the weapon record (`wWeaponFire`, `wWeaponUpdate`, from `WeaponTab`),
object type 8 (`PlacedItemRoutine`, through `OBJ_BANK` = `$01`) and the ROM0
stub `$0171`. Bank `$00` also reads two of its tables directly: `BitMasks` and
`AtomicFireDamage`. Bank `$01` never switches banks itself; its only far reach
is through bank `$00` helpers such as `LoadObjectTiles` and the screen loaders.

What it holds, in ROM order, is listed at the top of `banks/bank01.asm`. Nearly
three quarters of it is Mega Man and his weapons; the menus and HUD that the plan
expected to dominate are about 2 KB.

## Bank `$09` and the object library (step 5.2)

The three object banks are built the same way: an entry table of one `jp` per
object type, in `ObjectTypeTab` order; then the **object library**, 1794 bytes of
helpers (movement in 8.8 and 4.4 fixed point, gravity, block collision, facing,
animation, boss set-up and the boss bar, `SpawnChildObject`, solid platforms,
line movement); then the object routines. The library is identical in all three
banks except for its addresses (`$03`:`$4042`, `$09`:`$4048`, `$0D`:`$401B`), so it
is one file, `engine/object_library.asm`, included by each bank in its own pinned
section with `OBJBANK` set to the bank's label suffix (`_03`, `_09`, `_0D`).

An object routine gets B = 0 at spawn, 1 every frame, 2 when its hit points reach
zero and 3 (instead of 1) while Ice Slasher's freeze timer runs; B = 0 on return
removes it. Objects make objects with `SpawnChildObject`: the type in `$CC07`, the
position in `$CC0D`/`$CC0F`, then the parent runs the child's init itself. Bank
`$09`'s 24 types are listed with their spawners in `banks/bank09.asm`; each has
its own file in `engine/objects/` with a comment on its behaviour.

The Wily 2 bosses do not end their own fights: Bubble Man's and Heat Man's shots
(types 41 and 45, placed in the boss rooms and parked off screen until the boss
asks for them through `$CCF6`) and a parked type 43 beside Flash Man watch for the
boss's death (`CheckBossDead`) and start the victory countdown.

## The banks no literal selects

Banks `$03`, `$05`, `$08`, `$09` and `$0D` are never bank-switched to by a literal.
Of the 117 `bankswitch` sites, 26 take their value from somewhere else, and they sort
into exactly four mechanisms:

| Mechanism | Sites | Banks it can select |
|---|---:|---|
| `ld a,[wAudioBank]` — the audio pair | 6 | `$02`, `$0A` |
| `pop af` — restore a saved bank | 7 | whatever was saved |
| `ld a,[wStageBank]` — the current stage's data bank | 10 | `$05`, `$08`, `$0E` |
| `ld a,[hl]` at `OBJ_BANK` — an object's own code bank | 2 | `$03`, `$09`, `$0D`, `$01` |

**Stage banks come from `StageLoadTab` (`$2F93`).** `LoadStage` (`$3000`) pages in
bank `$05` first (there is no shared stage code there - step 4.1 found bank `$05`
is all stage data plus each stage's own hooks - and `LoadStageTiles` switches to
`$0C` straight away, so the write looks redundant), indexes the table with `wSelectedStage`, and
stashes the record's bank byte in `wStageBank` (`$DF9B`) before paging it in. Eight
four-byte records: the four robot master stages point at bank `$05`, the four Wily
stages at bank `$08`, selected by `wWilyStageSet` adding 4 to the index.

The table is indexed **one-based** — `LoadStage` loads `HL` with `$2F8F`, four bytes
before the data, so index 1 lands on the first record. Those four bytes are the
`dec b / jr nz / ret` tail of `HideAllSprites`, so the bias points into code rather
than padding. `wSelectedStage` is zero-based on the stage-select screen and
incremented by bank `$01` at `$062BA` before the load, which reconciles the two.

**Object banks come from `ObjectTypeTab` (`$3693`).** 56 four-byte records, each
`dw <handler>` + `db <bank>` + an unused `$00`. When an object is processed, the
far-call sites at `$28A3` and `$2A5B` read the bank out of the object's own record at
`OBJ_BANK` (`+$1B`) and page it in before jumping to the routine address in the
record's first two bytes (`CallObjectRoutine`). Offsets `+$15`/`+$17`, once read
as a handler and its jump index, are the frame table (`OBJ_FRAMES`) and frame
(`OBJ_FRAME`) - step 5.2.

Every handler address in that table is a slot in the target bank's entry table, and
**every slot in banks `$03`, `$09` and `$0D` is referenced exactly once, in order** —
22, 24 and 9 respectively, which is precisely how many `jp` entries each of those
banks has. The 56th record points at a lone bank `$01` address. So those three banks
exist to hold object behaviour code, and `ObjectTypeTab` is their complete index.

Still open: nothing has been traced *writing* `OBJ_BANK`. The two sites that touch it
only read it, so the field is filled at spawn time by a route that does not use the
`ld a,$1B / add a,c` idiom — probably a bulk copy from a template. Finding the spawn
path is the next thread, and it should also give the 56 object types their names.

## Regional versions

Eleven of the sixteen banks — `$02`, `$03`, `$07`, `$08`, `$09`, `$0A`, `$0B`, `$0C`,
`$0D`, `$0E`, `$0F` — are byte-identical across the US, European and Japanese dumps.
Only `$00`, `$01`, `$06` (code and localised screen data) and small patches of `$04`
and `$05` differ. See `docs/VERSIONS.md`. Two consequences worth remembering: the audio
disassembly applies to every version unchanged, and third-party documentation about
those eleven banks needs no address correction.

## Free space

About 61.8 KB of the 256 KB is padding — bank `$0F` entirely, plus 10.5 KB in `$0B`
and 7.2 KB in `$0D`. All tails are pure `$FF` except banks `$04` (95 `$00` bytes),
`$05` (127) and `$07` (4).

## What the audio disassembly already tells us

`audio/bank02.asm` documents the whole sound engine: eight slots (4 SFX + 4 music),
per-channel priority, a command/event language (`Audio1_Event*`), envelope sequences,
vibrato, sweeps, duty and waveform control, macros with a return stack, and an RNG
event that calls out to ROM0's `FuncRNG`. Bank `$0A` is the same driver again with a
different music set — which is why the game needs two audio banks at all.

## RAM addresses known so far

The authoritative list is now `ram/wram.asm`, `ram/hram.asm` and
`docs/RAMMAP.md`. What follows is the short version.

| Address | Meaning | Source |
|---|---|---|
| `$C000`–`$C09F` | OAM mirror, 4 bytes/sprite (Y, X, tile, attributes) | Data Crystal |
| `$C0D0`–`$C0D2` | three-byte `jp` that `CallBank1Routine` writes and then calls | this repo |
| `$C0B0`–`$C0C6` | `wBank1Trampoline`: 23 bytes of code copied in by banks `$0B`/`$0C`/`$0E` to call into bank `$01` (step 3.3) | this repo |
| `$C108` | lives | Data Crystal |
| `$C200`–`$C29A` | weapon and shot state: shot count, shoot timer, two hit lists, the equipped weapon's record (`wWeaponDamage` … `wWeaponPierce`, with its fire/update `jp`s), three shot slots at `$C239`, Mirror Buster's capture list (step 5.1) | this repo |
| `$D300`–`$D3D9` | explosions: twelve `$10`-byte records, free list, count `$D30C` (step 5.1) | this repo |
| `$D400`–`$D4C5`+ | items: ten `$10`-byte records, lists, refill state `$D4BE`–`$D4C1`, placed-item list `$D4C3` (step 5.1) | this repo |
| `$D802`–`$D846` | Mega Man: `wPlayerState`, `wPlayerFacing`, `wPlayerAnim`, `wPlayerX`/`wPlayerY`, `wHurtTimer`, joypad copies, `wPlayerMotion` (step 5.1) | this repo |
| `$C131` | `CondFlag1` (audio) | audio disassembly |
| `$D935`+ | audio engine RAM (see `ram/audio_ram.asm`) | audio disassembly |
| `$DF99` | `wCurrentBank` — current ROM bank shadow | this repo |
| `$DF9A` | `wAudioBank` — selected audio bank (`$02` or `$0A`) | this repo |
| `$DFA1` | unlocked weapons bitfield 1 (Buster/Cutter/Thunder/Ice/Fire/Carry/Atomic/Time) | Data Crystal |
| `$DFA2` | unlocked weapons bitfield 2 (Quick Boomerang/Bubble Lead/Mirror Buster) | Data Crystal |
| `$DFA3`–`$DFAD` | energy: HP first, Mirror Buster last, caps at 98 | Data Crystal |
| `$DFAE` | RNG seed | this repo |
| `$DFAF` | RNG table index | this repo |
| `$FF8C`–`$FF90` | `hFarCallA`…`hFarCallD` — register save slots for `FarCallAudio` | this repo |
| `$FF91` | `hBank1CallIndex` — routine index held by `CallBank1Routine` | this repo |

Step 1.2 added the VBlank bookkeeping (`wFrameCounter`, `wVBlankDone`,
`wVBlankBusy`, `wVBlankCount`), the LCD shadows (`wShadowLCDC`, `wShadowBGP`,
`wShadowSCX`, `wShadowSCY`), `wShadowOAM`, `wLives`, `wCurrentWeapon`,
`wBossesDefeated`, `wSelectedStage`, the metasprite scratch block and the
stage-select state. See `docs/RAMMAP.md` for all of it plus the unnamed
remainder.
