# Progress

## Coverage

`python3 tools/coverage.py --md`, as of step 5.2:

| Bank | Assembly | Raw INCBIN | Padding | Bank done |
|-----:|---------:|-----------:|--------:|----------:|
| $00 | 16,384 | 0 | 0 | 100.0% |
| $01 | 16,384 | 0 | 0 | 100.0% |
| $02 | 15,523 | 0 | 861 | 100.0% |
| $03 | 1,860 | 13,473 | 1,051 | 12.1% |
| $04 | 13,336 | 3,048 | 0 | 81.4% |
| $05 | 15,021 | 1,363 | 0 | 91.7% |
| $06 | 16,384 | 0 | 0 | 100.0% |
| $07 | 16,384 | 0 | 0 | 100.0% |
| $08 | 16,384 | 0 | 0 | 100.0% |
| $09 | 16,384 | 0 | 0 | 100.0% |
| $0A | 12,813 | 0 | 3,571 | 100.0% |
| $0B | 3 | 5,581 | 10,800 | 0.1% |
| $0C | 16,384 | 0 | 0 | 100.0% |
| $0D | 1,821 | 7,156 | 7,407 | 20.3% |
| $0E | 3 | 15,276 | 1,105 | 0.0% |
| $0F | 0 | 0 | 16,384 | n/a (empty) |
| **Total** | **175,068** | **45,897** | **41,179** | **79.23%** |

"Bank done" is assembly as a share of that bank's real (non-padding) content.
Padding is currently re-emitted from the base ROM by the `freespace` macro and is
not counted either way.

## Session log

### Step 5.2 — bank `$09`, the first object bank (2026-10-08)

* **Bank `$09` is 100% source**, byte-identical (whole ROM **79.23%**). It was
  bootstrapped by `tools/bankgen.py`, the step 5.1 generator made general (one
  config per bank: `tools/bankgen/bank09.py`; `bank01.py` reproduces bank `$01`).
  `banks/bank09.asm` is the include list and map; `engine/objects/` has the entry
  table and one file per object type.
* **The object library.** Bytes `$4048`-`$4749` are 1794 bytes of helpers that
  banks `$03` (`$4042`) and `$0D` (`$401B`) carry too, identical except for
  addresses. It is one file, `engine/object_library.asm`, included by all three
  banks with `OBJBANK` = `_03`/`_09`/`_0D` interpolated into its labels; so banks
  `$03` and `$0D` are now 12% and 20% source.
* **How objects make objects** (the open question from 4.3): `SpawnChildObject`
  - the type in `$CC07`, position `$CC0D`/`$CC0F`, tile base and params
  `$CC05`-`$CC08`; the parent then runs the child's init itself. Every caller in
  the ROM was found: in bank `$09`, 12 spawns 11, 15 spawns 14, 14 spawns 26, 24
  spawns 25, 19 spawns 27, 27 spawns six 28s, Enker (38) spawns 39 and Flash Man
  (42) spawns 54; bank `$03` spawns 18 and 35, bank `$0D` 49-52. **Type 13 is
  unused**: nothing places or spawns it (UNUSED.md) - an unfinished platform.
* **Object routine modes**: B = 0 spawn, 1 frame, 2 hit points gone, 3 frozen by
  Ice Slasher; return B = 0 to be removed. **Offsets `$15`/`$17` are the frame
  table and frame**, not a handler and its index: renamed `OBJ_FRAMES` and
  `OBJ_FRAME` (`constants/objects.inc`). The routine address is the record's
  first two bytes.
* **Every routine has a behaviour comment** (read for this step, with the frames
  drawn by the new `tools/objframes.py`). Named, from the code: Enker and his shot
  (39, `EnkerShot`: power from the damage he absorbs), `FlashManFreeze` (54: stops
  Mega Man for 90 frames - presumably the Time Stopper `[?]`),
  `FlashManDefeatWatcher` (43), and 125 internal routines and tables. The five type
  41s and three type 45s **are Bubble Man's and Heat Man's shots** during the
  fight (asked for through `$CCF6`), not weapons placed for afterwards as step 4.3
  read them; with the parked type 43 beside Flash Man, they end those bosses'
  fights. Enker takes damage only while jumping or absorbing, from the Mega
  Buster `[?]`. The 14 enemy types keep `ObjNN` names until Will identifies them.
* Bank `$00`: the object banks' stubs are named (`JumpCheckSolidPoint`,
  `JumpSpawnExplosionBurst`, `JumpAddSolidBox`; `CheckSolidPoint` at `$0F96`).
  `CheckPlayerInBox` returns carry when Mega Man is *outside* the box.
* `$CCF2`-`$CCFA` double as boss-fight state (RAMMAP): `$CCF5`, which step 5.1
  saw cancel damage, is the boss-beaten flag.
* Found along the way (UNUSED.md): six dead routines, including one that writes
  background tiles where the boss door is; five library routines bank `$09`
  never uses; five orphan frames; two unreachable branches.

**Open questions carried forward:**

* Will: what are types 4, 10, 11, 12, 15 (with 14 and 26), 19 (with 27, 28) and
  24 (with 25) in the game? Renders and behaviour are in the step 5.2 notes.
* Is type 54 the Time Stopper, and type 39 the Mirror Buster (offset `$1A` as a
  shot's damage to Mega Man)?

### Step 5.1 — bank `$01`, the resident bank (2026-10-07)

* **Bank `$01` is 100% source**, byte-identical (whole ROM **70.45%**; the bank's
  `$FF` tail is now an explicit `ds`, which the tool counts as assembly, so part
  of the jump from 64.16% is that). It is split by subsystem like bank `$00`:
  `engine/weapons.asm`, `items.asm`, `explosions.asm`, `pause_menu.asm`,
  `hud.asm`, `title_menu.asm`, `stage_select_menu.asm`, `weapon_get_screen.asm`,
  `picture_viewer.asm`, `player.asm`, and `data/weapon_frames.asm`,
  `data/megaman_frames.asm`; `banks/bank01.asm` is the include list and map.
  Code was found by recursive descent from every entry point (bank `$00`'s calls,
  `CallBank1Routine`, the RAM hooks, `ObjectTypeTab`'s type 8, WeaponTab's 22
  handlers); everything else was classified by hand. 424 labels; 47 (all code)
  are still provisional, nearly all tails of the player physics and the item
  and explosion loops, and each has a comment.
* **The bank is the player and his weapons**, not the HUD-and-menus bank the plan
  expected (those are 2 KB of the 13): WeaponTab (one 16-byte record per weapon,
  including the fire and update routines), `TryFireWeapon`/`UpdateShots` and
  three `$20`-byte shot slots at `$C239`, each weapon's behaviour (Rolling Cutter's
  arc and homing return, Thunder Beam's three bolts, Fire Storm's orbiting shield,
  Atomic Fire's charge levels, Time Stopper's `$DFB1` bit 3, Mirror Buster
  catching enemy shots and firing them back), items and drops, explosions, the
  pause menu, the HUD, the title and stage-select screens, the weapon-get screen,
  and all of Mega Man's movement - walking, jumping (variable height), ladders,
  knockback, gravity (lower under water), collision, drawing, teleporting.
* **Answers to carried questions.** `wHookA` (`$C0AA`) is called by
  `UpdatePlayer` whenever Mega Man can act - it is the fire button. Collision
  values: 0 passable, 3 solid, 1 solid in the block's lower half (spikes), 2 in
  its upper half (ladder tops); blocks 1 and 2 are tested by number as ladder and
  ladder top (`CheckSolidAt`, bank `$00`). `$D908` is the floor type (2 = ice:
  walking accelerates at 4 instead of $40), `$D909` the underwater flag.
* **Shot damage.** A shot's offset `$0B` is its damage, and the hit list points
  the collision pass straight at it: a hit subtracts the enemy's value from it,
  so a shot can survive a weak enemy, per the weapon's pierce flags. Atomic Fire's
  charge levels do 1, 2 and 5, and bank `$00` scales boss damage by the same.
* **Item drops**: one FuncRNG roll per kill. Below `$9A` nothing, `$9A` an extra
  life, then big health, small health, big energy and small energy (3, 24, 10
  and 64 values of 256). Placed items (object type 8) are
  remembered once collected.
* **Found along the way:** `FreeAllShots` stops after two of the three slots;
  four unused picture viewers; an unreachable hang trap; three unreferenced data
  items (UNUSED.md). The weapons' two-letter names (P, CU, EL, IC, FI, CA, HE, FL,
  QU, BU, EN) are the bosses' initials, now text in a new `menu` charmap; "AND
  CARRY" is text in `getscreen`.
* RAM: 40 new labels for the shot state (`$C200`-`$C29A`), the weapon record,
  Mega Man (`wPlayerX/Y`, facing, motion, animation, hurt timer, joypad copies),
  `wFloorType`, `wUnderwater`, `wFreezeFlags` (`$DFB1`), `wTeleportState`; bank
  `$00` now uses them, and its calls into bank `$01` are by name.

**Open questions carried forward:**

* `$C22D` (a new shot's offset `$00`): non-zero marks the slot in use, bit 1
  puts the shot on the hit list, 1 is a deflected pellet - the rest is untraced.
* `$C217`, `$DF93`, `$D869`, `$D845` are used by bank `$01` but not
  understood (`$DF93` stops contact damage).
* `Func_01_65AB` (after a stage is chosen) and the HUD digit table's layout.
* `$41E6`: eleven bytes per weapon that nothing reads - nine match the weapons'
  firing sounds (UNUSED.md).

### Follow-up from Will after 4.4 (2026-10-07)

* **Boss weapons and Wily objects identified** (labels renamed in bank `$07`,
  `data/gfx_pointers.asm` and `ObjectTilesetPtrs`; spawns and ObjectTypeTab
  annotated): 31 Rolling Cutter, 33 Ice Slasher, 37 Fire Storm, 41 Bubble Lead, 45
  Atomic Fire, 47 Quick Boomerang (each placed beside its boss), 48 Dr. Wily and
  the Wily Machine's sprite parts including its wheel enemy, 53 the light on an
  active teleporter, 55 the boss door; 39 possibly the Mirror Buster. The PNGs
  keep their `obj_typeNN` names for now.
* Consequence: objects can create other objects - the wheel enemy (likely 49-51,
  which share 48's tiles) and maybe 39 are never in a spawn list. That route is
  not in `SpawnObject`'s one caller; Phase 5.
* Open: type 37 (Fire Storm) is also placed beside Elec Man; type 43 (beside
  Flash Man) loads the Rolling Cutter's tiles.

### Step 4.4 — bank `$07` (2026-10-07)

* **Bank `$07` is 100% source**, byte-identical on the first build; whole ROM
  **64.16%**. **Phase 4 is complete.** The bank is graphics, not object placement
  (placement is in the room records, 4.1).
* **Object types 30-56:** 21 tileset records and their tiles, now PNGs in
  `gfx/bosses/` - `cut_man`, `ice_man`, `elec_man`, `fire_man` (each spawned in
  that master's boss room, and loaded for his stage-select portrait), `enker`,
  `bubble_man`, `flash_man`, `heat_man`, `quick_man` (4.3), the rest by type.
  Shared: 43 uses 31's tiles, 35 uses 33's, 49-51 use 48's, 54 uses 53's.
* **What the tiles show:** type 56's spell "DR.WILY TELEPORT SYSTEM" - it is the
  hub's sign, not a teleporter (corrects the 4.3 guess); type 41's are bubbles
  (Bubble Man's room); type 55's are the shutter stripes, which backs type 55 as
  the boss shutter; type 48 has 116 tiles, almost all of sprite VRAM.
* **The stage-select robot masters** are bank `$07` data too: four tile lists
  (count, then a source tile per destination tile, `$FF` blank) that
  `Func_00_1B88` uses to build each master's sprite tiles out of his boss
  tileset, 19 metasprite frames (`Func_00_1C6D`'s format: cols/rows byte,
  8x16 tile pairs, extras to `$80`), and two 45-step jump arcs. Rendered with the
  new `tools/stageselect.py` to `docs/sprites/stage_select_robot_masters.png`:
  standing poses and the jump frames, all four correct. The ROM0 slots
  `$036D`-`$03A9` are now `GfxRef_*` names, and `engine/stage_select.asm` uses
  them instead of literals.
* **The Wily Machine room solved:** its blockset draws background tiles 0-`$4F`
  of bank `$06`'s Wily Machine cutscene graphics - with those, the room shows the
  machine as background. `leveldump.py` loads them (`BLOCKSET_TILES`); the
  render in `docs/levels/7_wily3.png` is fixed. The loading code is not traced.
* Type 52's tileset entry would load type 47's tiles (UNUSED.md).

### Follow-up from Will after 4.3 (2026-10-06)

* The Wily renders match the game, except the Wily Machine room, which fades in
  from black with a tileset the stage data does not name, so the render is
  garbled. Source of those tiles still untraced (LEVELS.md "Render limits").
* Object types, as Will's identifications (`[?]` until traced): 53 teleporter
  (spawned with its number as Y), 56 the teleporter to Enker (placed at Enker's
  teleporter's X), 48 the Wily Machine or part of it. Bubble Man's room is the
  game's only underwater area and has bubbles, which fits `$D909` and maybe
  type 41. Annotated in `data/object_tables.asm` and the Wily stage files.

### Step 4.3 — the Wily castle (2026-10-06)

* **Bank `$08` is 100% source**, byte-identical on the first build; whole ROM
  **57.18%**. New stage files `wily1.asm`, `wily2.asm`, `wily3.asm` and
  `wily2_test.asm`; bank `$08` pinned at `$4000` with a `ds` tail. Renders for
  stages 5-7 and 9 in `docs/levels/`.
* **Wily 1 runs straight into Wily 2.** Its last room's exit leads into Wily 2's
  hub room; on the way down its frame hook streams Wily 2's tiles into VRAM in
  $40-byte chunks (`QueueTileCopy`/`CopyQueuedTiles` at `$08:4008` - the routine
  bank `$0C` has a dead copy of - from a second copy of the tiles kept in bank
  `$08`), and the hub's room routine swaps in Wily 2's blockset and hooks with
  `SwapRestartData`. Wily 3 uses the same call to switch to the Wily Machine
  room's own blockset.
* **Wily 2 is the teleporter hub.** A state machine fades in, watches for Mega Man
  standing exactly on one of five teleporters, fades out and loads that
  teleporter's restart record through `JumpLoadRestartPoint`, so each boss room
  starts as a stage. Bosses, named through the weapon each awards
  (`wHubTeleporter` + 4 on the weapon-get screen): **Quick Man (type 46),
  Bubble Man (40), Flash Man (42), Heat Man (44), Enker (38)**. The plan's list of
  six Mega Man 2 bosses was wrong. Wily 3's last room spawns type 48.
* **RAM:** `wWilyProgress` (`$DF96`: hub bosses beaten, bit 7 hub reached),
  `wHubTeleporter` (`$DF97`), the hub state `$D90A`-`$D90F` and the tile copy
  `$D910`-`$D916`, substituted through the engine.
* **Leftovers:** an unreferenced ninth stage at `$08:6D05` that lays out Wily 2's
  four room layouts side by side (a test stage); Wily 1's third restart point is
  Wily 2's start and unreachable, with an orphaned Wily 1 record beside it; an
  orphaned Wily 3 record; duplicate Wily 2 checkpoints; an unreadable teleporter
  table entry. All in UNUSED.md.
* **Unplaced object types, now final for the stage data:** 13, 14, 25-28, 35, 39,
  49-52, 54.
* `leveldump.py` handles all nine stages: per-room blocksets, restart records
  outside the table, exits that leave a stage.

### Step 4.2 — stages as macros (2026-10-06)

* **Every decoded stage is now editable source** in `data/stages/` (Cut Man,
  Ice Man, Fire Man, Elec Man, alternate Fire Man), written with the new
  `macros/stages.inc`. Layouts are `lrow "0D 20 21 ..."` strings - one row of
  hex block numbers per line, so a room reads as a picture - and blocks are
  `block tl, tr, bl, br` in on-screen order. Byte-identical on the first build.
* **The macros guard edits:** row width and row count per layout, exit length,
  no type-0 spawn, the block count computed from labels, and a collision table of
  exactly one byte per block (at most 64). Each check was tested by breaking a
  copy of the source on purpose.
* **Bank `$05` is pinned at `$4000`** and its padding is `ds $8000 - @, $FF`
  instead of `freespace`, so stages can grow by about 4 KB (5.3 KB if the
  filler `INCBIN` is deleted). Coverage counts that padding as assembly, as it
  does for banks `$00`/`$06`/`$0C`: bank `$05` 22.3% → 91.7% (the 8.3% left is
  the filler), bank `$08` 2.4% → 15.6%, whole ROM **51.08%**.
* Docs: LEVELS.md "Editing a stage" (with how to preview an edit through
  `leveldump.py mmwr.gb`), a "Stage data" section in CONVENTIONS.md.

### Follow-up from Will after 4.1b (2026-10-06)

* **Prototype boss doors are non-functional** - Mega Man walks through them and
  they never open. That matches the alternate Fire Man stage's corridor door,
  which is passable map blocks with no object attached (UNUSED.md).
* **Object type 9 is a fan** that blows Mega Man away; **type 29 is a block only
  Atomic Fire can destroy**. Labels renamed (`FanTiles`/`FanGfx`/`GfxPtr_Fan`,
  `AtomicFireBlockTiles`/`AtomicFireBlockGfx`/`GfxPtr_AtomicFireBlock`) and the
  ObjectTypeTab entries and bank `$05` spawns annotated. The PNGs keep their
  `obj_typeNN.png` names for now. Fans are placed in Elec Man's stage and Wily
  stages 1 and 3; the Atomic Fire blocks only in Wily stage 3 (four).

### Step 4.1b — the alternate Fire Man stage (2026-10-06)

* **Rendered** (`docs/levels/8_fire_man_alt.png`) and **made source**: bank `$08`
  `$6F67`–`$7828` is now records, code and labelled layout/blockset `INCBIN`s
  like bank `$05`, so the build proves the parse. `StagePtr_FireManAlt` replaces
  `Ptr_08_4006`. Bank `$08` 0.1% → 2.4%; whole ROM **45.29%**.
* **Compared with the final stage:** 9 rooms against 13, all downward; only the
  first room is (nearly) the same; 4 spawns against 57 - two type 8 and the boss
  pair, so the map looks finished and the enemies not placed. Same block parts
  (27 of 36 definitions identical, identical collision), own tileset.
* **The shutters are drawn into its layouts** - the only stage where they are: a
  passable 2×4 door of block 3 in the corridor room (beside the same blocks 4–7
  group that flanks object type 55 in the final stages), and a solid 1×4 door of
  the last block in the **left wall of the boss room**. That is the only
  side-wall door anywhere, nothing leads through it, and it is the strongest
  trace yet of the side-by-side boss doors. Written up in UNUSED.md.
* **Its frame hook** is Fire Man's palette cycle (colour 3 darker) and the spike
  test, without the behind-BG zone code - so that code, identical to Elec Man's,
  was added to the final Fire Man hook later and never given any zones.
* `leveldump.py` gained the stage's first-frame palette (`$8F`).

### Step 4.1 — bank `$05` level data format (2026-10-06)

* **Format decoded and proven by the build** — written up in `docs/LEVELS.md`.
  Stage header → restart points (start + one per checkpoint; 14-byte records:
  blockset, collision table, init, frame hook, Mega Man's start X/Y, start room)
  and a checkpoint list → rooms (id, routine, layout, X offset, two exits, spawn
  list). Layouts are 8 rows of 16×16 blocks; blocks are 4 tile numbers (TL, BL, TR,
  BR); one collision byte per block. Rooms connect only vertically. The old notes'
  "sections" are restart points and "sub-sections" are rooms.
* **Bank `$05` 0.1% → 22.3%**, whole ROM **45.13%**. Every header, restart point,
  checkpoint, room, exit and spawn is `db`/`dw` source with labelled pointers, so
  any mistake in the format would have broken the build. Layouts and blocksets
  are still `INCBIN` (labelled), for 4.2. The four stages' own code is source:
  Cut Man's conveyor belts and palette flicker, Ice Man's ice blocks (`$D908`),
  spikes (block 8, all stages), Fire Man's palette cycle, and the behind-BG zones
  that put Mega Man behind Elec Man's clouds - Fire Man has the same code with an
  empty table.
* **Bank `$00` loader named:** `UpdateRestartPoint`, `LoadRestartPoint`,
  `CheckRoomExits`, `DrawRoomView`, `LoadRoom`, `BuildExitBoxes`,
  `BuildExitBox`, `DrawBlock`, `JumpLoadRestartPoint`; 18 WRAM labels for the room
  state (`wRestartPoint`, `wRoomID`, `wExitBoxes`, `wBlockCollision`, …).
  `wStageParams` became `wRestartPointsPtr` + `wCheckpointsPtr`.
* **`tools/leveldump.py`** dumps any stage and renders it to PNG (`--objects`
  marks spawns by type, `--blocks` writes the blockset sheet), pairing data and
  tiles through the game's own tables. Renders of stages 1–4 are in
  `docs/levels/` - confirmed against the game by Will.
* **`$16AAD`–`$16F21` explained:** the stage data ends at `$16AAD`; the rest of
  `$6AAD`–`$6FFF` is the same uninitialised-memory filler as bank `$04`'s.
* **Vestigial boss-door candidate** (UNUSED.md): side-wall exits that
  `BuildExitBox` supports and no stage uses. Also unused: restart-point byte 0,
  the checkpoint records' second byte. **Object types 13 and 14 are never placed.**
* **Follow-up from Will:** the renders match the game. The final game has one
  boss shutter per stage (walk through it, then drop into the boss room), so the
  striped open/closed block pair that no layout places is that shutter, drawn at
  run time - most likely by object type 55 (bank `$09` slot 23), which each stage
  spawns once at column 5, Y `$30` of the room before the boss room.
* **Password sounds confirmed by Will:** a correct password plays the extra-life
  jingle (ID `$10`), a wrong one explosions (`$02`) and Mega Man's death explosion
  (`$0F`). That matches the "SoundTab index + 1" rule in `QueueSound`'s notes;
  bank `$0C` comments updated.
* Correction: `LoadStage` does not page in bank `$05` "for shared stage code" - there
  is none; the write is redundant.

### Step 3.3 — bank `$0C` (2026-10-05)

* **Bank `$0C` is 100% source**, byte-identical; whole ROM **43.82%**. Step 3.4's
  compression audit closes with nothing found: banks `$04`, `$06` and `$0C` hold
  only plain tiles and maps.
* **Stage tilesets.** Eight `LoadStageTiles` lists, one per stage, each loading the
  stage's own tiles at tile 0 plus two shared runs at 98 and 112. PNGs in
  `gfx/stages/`. The unused eighth slot's set (`fire_man_alt.png`) is 79 tiles like
  Fire Man's, in the same style, with 18 tiles identical to his.
* **`wBank1Trampoline`** (`$C0B0`) is code, not a table: `FarCallBank1` (`$C:4016`)
  copies a 23-byte call-into-bank-1 routine there. Banks `$0B`/`$0E` carry the same
  kit. Closes the open question about `$C0B0` overlapping the RAM-code block.
* **The password system.** `$4010` is `EnterPassword`, `$4013` `ShowPassword`.
  Passwords are five balls on a 4×4 grid (rows A–D, columns 1–4); a password
  encodes only which of the four robot masters are beaten, so there are exactly
  16, all in `PasswordTable` (decoded in the source). A match rebuilds
  `wWeaponsUnlocked1`; a wrong password plays an ERROR sequence and then
  `CheckPasswordEntry` (now `[ok]`) resets the game. The password screen reuses
  the stage-select graphics through `LoadStageSelectScreen` (CallBank1Routine 3),
  which answers how it shares the cursor look; its grid is
  `gfx/tilemaps/password.tilemap`, its sprites a full ASCII font plus the balls
  (`gfx/screens/password_sprites.png`).
* Dead code: copies of a bank-`$08` routine and of the bank-`$0B`/`$0E` sprite kit.
* Also named every `$0150` jump stub after its target (`JumpQueueSound`, …).
* **The `$0D0D` tiles are a disabled hitbox viewer** — see the 3.2 follow-up note
  below and UNUSED.md.

### Step 3.2 — bank `$06` tilemaps (2026-10-05)

* **Bank `$06` is 100% source** (whole ROM **36.55%**), byte-identical. Nothing in it is compressed: the
  21 pointer slots lead to plain (byte count, tiles) records read by
  `Func_00_2516` and plain tilemap pointers read by `Func_00_2521`. Tiles are
  PNGs in `gfx/screens/` (9 files), maps are raw `gfx/tilemaps/*.tilemap` (8 files).
* Each screen was rendered by replaying its loader into a simulated VRAM: the
  **title logo** (20x10 map with a size header — iimarckus's label was 3 bytes
  late because it missed the header), the **menu font**, the **stage-select**
  portrait grid (two 20x9 halves, the second on the window), the
  **weapon-get** screen (Mega Man in cutaway, a raw 32x18 map), and four
  cutscene pictures bank `$01` shows in a row — **Dr. Wily's skull castle**, a
  **skull-faced flying machine**, and a **beaked machine** in two versions. The
  last two are named by what they show, `[?]`, pending Will.
* Named the loaders: `LoadWeaponGetScreen`, `LoadWilyCastleScreen`,
  `LoadSkullShipScreen`, `LoadBirdMachineScreenA`/`B`, `CopyTilemap20x18`, and the
  `GfxRef_*` slots in bank `$00`.
* Unused: a blank 11th row after the title map, three rows after the stage-select
  map, and `Func_00_01BD` — an uncalled second skull-ship loader whose row copy
  would shear the picture.
* Step 3.4's compression audit is half answered: bank `$06` has none.

* **Follow-up with Will.** The beaked machine is the **Wily Machine**, the final
  boss: the map with the dome is phase 1, the one without is phase 2 with Dr. Wily
  visible. Renamed to `WilyMachine*` (`wily_machine.png`,
  `wily_machine_phase1/2.tilemap`). Will also spotted **WORLD** among the title
  tiles: 32 of the 110 title tiles are never placed by the map, including WORLD in
  the logo's lettering — a trace of a *Mega Man World* title, matching Japan's
  *Rockman World*. Checked the other ROMs: Europe has the same unused tiles,
  while *Rockman World*'s WORLD is a different, grey italic drawing not found in
  the US ROM — so the US WORLD was drawn in the *MEGA MAN* lettering for an
  English logo that was then cut. Logged in UNUSED.md.

* **The `$0D0D` tiles are a disabled hitbox viewer.** Will could not find the five
  "background" tiles in any stage map; following their code showed they are
  sprite tiles for a developer tool: freeze play, move a ring cursor, hold B to
  bracket the hitbox under it. Its frame routine (`$0D76`, previously "a
  Start-button check with no caller") is unreachable and its sprite handles are
  never allocated. The `$0D5D` "records" are five one-tile metasprites (four
  flips of a corner, plus the cursor). Named `HitboxViewer*`, documented in
  UNUSED.md and RAMMAP.md; `gfx/bg_tiles_0d0d.png` → `gfx/hitbox_viewer.png`.

### Step 3.1 — bank `$04` sprite graphics (2026-10-05)

* **Every tile run in bank `$04` is a PNG** under `gfx/sprites/` — 39 files — built by
  `rgbgfx`, and the ROM is byte-identical on the first build. `build.sh` and
  `make.bat` now also convert `gfx/*/*.png`. Bank `$04` 1% → 81%; the remaining
  19% is 3,048 bytes of uninitialised-memory filler at `$63F8`, kept as `INCBIN`,
  and the `$FF` tail is now `ds`. Whole ROM **28.90%**.
* **Mega Man, the item pickups, all eleven weapon shots, the health bar and the
  seven-segment digits** were rendered and match their names; promoted to `[ok]`.
* **The 27 unnamed pointers** are one stage-select graphic (`Ptr_04_401E` →
  `Tiles_04_4F5B`, a ring and dots, loaded by `Func_00_1B6B`) and 26 object-type
  tileset records for types 1–29. Named by type — `GfxPtr_ObjTypeNN`,
  `ObjGfxTypeNN`, `ObjTilesTypeNN` — because rendered in tile order they are
  fragments, not recognisable enemies; assembling them needs the metasprite data
  in the object banks (Phase 5). A labelled contact sheet went to Will.
* Sharing: type 11 loads the first 8 of type 12's 42 tiles; types 25–28 share a
  record that loads 5 of type 24's 6 tiles; type 8's record has a count of 0.
* Unused: the filler, two orphan bytes at `$4F59`, and a never-read `$80` in type
  8's record.

* **Follow-up with Will's notes.** The stages and title screen use 8x8 sprites
  (`PlayStage` and `TitleScreen` clear LCDC bit 2 with `and $7B`), so the PNGs —
  plain 8x8 tiles in ROM order — are the right shape. *Correction, same day:* the
  stage select ORs `$64` into `wShadowLCDC`, which sets bit 2, so that one screen
  uses 8x16 sprites. Renamed per Will: `SevenSegDigits` → `HUD` (`hud.png`), type 20 →
  `AppearingBlock`, type 23 → `Icicle`. Type 20's stats flags are `$00` (not
  visible at spawn), which fits a block that appears; type 23 asks for 0 OAM
  entries, left for Phase 5. Will suspects type 13 is unused — logged in
  UNUSED.md, to be settled by the Phase 4 spawn lists, since `SpawnObject` has a
  single caller. Will thought `Tiles_04_4F5B` might be enemy shots, but in stages
  `FireEnemyShot` callers pass tile `$66`, a ring in Mega Man's own tile set
  (tile 102); `Tiles_04_4F5B` is loaded by bank `$01` beside `Func_00_1AFC`'s
  screen, so it belongs to a non-stage screen. Will also notes the ending shows
  each enemy's sprite with its name, which will name the object types.

* **The ring and dots are the stage-select sprites** (Will): the ring is the cursor
  on the stage select and password screen, the dots are the background stars of
  the stage-chosen animation. Corroborated: their only loader is called from bank
  `$01`'s stage-select setup (`$1:6181`, after it picks the first undefeated boss),
  and that screen uses 8x16 sprites, so the 8 tiles are four 8x16 images with
  blank lower halves. Renamed `StageSelectTiles` / `stage_select.png`,
  `LoadStageSelectSprites` (`$1B6B`), and `LoadStageSelectScreen` (`$1AFC`, the
  two-tilemap loader called just before it — which answers the open question of
  what screen it draws).

### Step 2.7 — bank `$00` split into `engine/` and `data/` (2026-10-04)

* `banks/bank00.asm` (8,642 lines) is gone. Bank `$00` is now 27 files — 24 under
  `engine/` and 3 under `data/` — holding 40 sections (the 7 vectors, the header
  and 32 code/data chunks), each pinned to its original ROM0 address, plus the
  free-space `ds` in `main.asm`. The ROM is byte-identical.
* No chunk falls through into another file: every chunk ends in an
  unconditional `ret`/`jp`/`jr`/`reti` or in data (checked by script).
* Pinning means a file can gather a subsystem from non-adjacent code: for
  example `engine/audio_interface.asm` holds the audio API stubs ($0227), the
  sound queue ($03CD) and the queue drain ($07DD); `engine/memory.asm` holds the
  copy/fill routines and the table lookups; `engine/screens.asm` holds the
  `$01BD` loader and the text screens; `data/object_tables.asm` holds
  `ObjectTablePtrs`, `ObjectStatsTab` and `ObjectTypeTab`.
* Fall-throughs inside files, unchanged:
  `ResetAndLoadStage` → `LoadStage` → `Func_00_3057` (all in `stage_load.asm`), and
  `Func_00_2A1E` → `Func_00_2A25` (in `objects.asm`).
* Three section names first collided with WRAM/HRAM sections (`Joypad`, `OAM DMA`,
  `Sound Queue`); section names are global, so the ROM ones were renamed. Added a
  "Moving code out of `banks/`" section to CONVENTIONS.

### Step 2.6 — `$34D3`–`$3979`, and bank `$00` finished (2026-10-04)

* **Bank `$00` is 100% source.** Its last `INCBIN "baserom.gb"` (`RNGTable`) is now
  16 rows of `db`, and the `freespace` tail is `ds $4000 - $3979, $FF` (all 1,671
  bytes checked to be `$FF`). Whole ROM **22.91%** (padding included).
* **`ObjectStatsTab`** (`$34D3`): eight bytes per object type, one-based — OAM
  entries, spawn X/Y offsets, hit points (offset `$18`), touch damage (`$1A`),
  flags (`$11`), an untraced byte (`$03`) and an unused zero. `ObjectTablePtrs`
  (`$01B9`) points the object banks at it and at `ObjectTypeTab`.
* **`BossDamageTab` confirmed** (was `Data_00_11B8`, `[?]`). The lookup keys on the
  struck object's type: types 30–49 except 48 pick a row, and those are exactly
  the boss records in `ObjectStatsTab` (hp `$13`, flag bit 6). The result is
  subtracted from hit points. Now `[ok]`.
* **Enemy shots** (`$3773`–`$3978`): a separate pool of 12 small projectiles at
  `$CD00`. `FireEnemyShot` (stub `$0153`) takes a position, one of 16 directions,
  a tile and touch damage; `EnemyShotVelocities` is 16 directions at 3 px/frame in
  8.8 fixed point, with slightly uneven diagonals. `UpdateEnemyShot` moves, culls,
  hurts Mega Man and — with **Mirror Buster** equipped — lets a Mirror Buster shot
  hit it and hands off to bank `$01` `$4FD0`, presumably the reflection. Also
  `InitEnemyShots`, `ClearEnemyShots`, `UpdateEnemyShots`.
* `RNGTable` is not quite a permutation: `$09` and `$BA` twice, `$00` and `$DA`
  missing.
* Unused: a `jr` + `$00` after a `ret` at `$387D`, and `ObjectStatsTab`'s byte 7.

### Step 2.5 — `$2C6B`–`$3496` (2026-10-04)

* **The three gaps are source**, byte-identical. Bank `$00` 78% → 92%; whole ROM
  **21.65%**. Only `$34D3`–`$3693` and `$3773`–`$3979` remain in bank `$00`.
* **The sprite system** (`$2C6B`–`$2F7F`). Objects hold a *sprite handle* (0–`$3F`,
  `$40` = none) rather than OAM entries. `AllocSprite` gets a handle sized in OAM
  entries; if the OAM pool (26 entries at start, by our reading) cannot cover it
  the sprite waits, and
  `RotateSpriteOAM`, run every frame, takes entries from the oldest holders and
  gives them to waiting sprites — the game's sprite flicker. Also `FreeSprite`,
  `UnlinkSprite`, handle and OAM-pool allocators, `DrawMetasprite` (header,
  tile grid, then a free-placed list; format documented at the routine),
  `DrawMetaspriteList`, `DrawObjectSprite`. Three more hang traps.
* **Correction:** object offset `$10` is that sprite handle. Step 2.4 had it as
  "a byte passed to `$2F0A` on death" and guessed at an explosion or item drop;
  `$2F0A` is `FreeSprite`. Comments and RAMMAP fixed.
* `ResetAndLoadStage` (`$2FF6`) zeroes `$D800`–`$D84D` and falls into `LoadStage`,
  which itself falls into the section loader at `$3057`.
* **The `$DF80` mystery is solved**: the section loader writes a `jp` there from the
  section record, and `StageFrameLoop` calls it each frame. Named `wStageHook`.
* Stage-section machinery, left provisional with comments for Phase 4:
  `Func_00_3057` (section record layout sketched), `Func_00_32F2` (sub-section
  setup), `Func_00_312F` (transition-box test — vertical screen scrolls),
  `Func_00_33F8`/`3412` (build the boxes), `Func_00_327F` (draw the screen).
  Named helpers: `CallHL`, `ClampToScrollLimits`, `PixelToBGMapAddr`,
  `PixelToBlockGridAddr` (a 16×16 grid of 16-pixel blocks at `$DE00`).
* Unused: `FreeOneOAMSlot` (`$2F70`), and a dead computation in `Func_00_2FB3`.

### Step 2.4 — `$21C7`–`$2245`, `$23A8`–`$2516`, `$252B`–`$2C37` (2026-10-04)

* **All three gaps are source**, byte-identical. Bank `$00` 63% → 78%; whole ROM
  **20.66%**.
* **Correction: step 1.5's "there is no other text" was wrong.** `$21C7` is the
  weapon-get screen's text (`YOU GOT`, then each weapon name on two lines) in a
  third encoding, ASCII + `$80` — the same font loaded 32 tiles higher. It is
  source now through a new `getscreen` charmap, with `WeaponNameLine1Ptrs` /
  `WeaponNameLine2Ptrs`. A re-sweep at all 256 byte shifts also found `ANDCARRY`
  in bank `$01` and the ending's enemy roll call in bank `$0E` (ASCII − `$20`),
  left raw for their own banks. The roll call names the enemies, which should
  help with the object types. ROMMAP, CONVENTIONS, PLAN and bank `$06` corrected.
* `LoadStageTiles` (bank `$0C` tilesets via one-based `StageTilesetPtrs`) — the
  unused eighth stage has **its own tileset**. `LoadObjectTiles` (12-entry type
  cache, sprite tiles from banks `$04`/`$07`, allocator `$C3B3`) and `CopyTiles`.
* **Object types are one-based.** `SpawnObject` indexes `ObjectTypeTab - 4` and
  `LoadObjectTiles` indexes `ObjectTilesetPtrs - 2`; `ObjectTypeTab`'s comments
  are renumbered 1-56 (they counted from 0).
* The object system core: `AllocObjectSlot` / `FreeObjectSlot` (stubs `$0174` /
  `$0177`), `SpawnObject`, `CallObjectRoutine` (jumps to the address in the
  object's first two bytes in its own bank, return to `.handlerReturn`; banks
  `$03`/`$09`/`$0D` also jump to `ObjectHandlerDone` at `$28B7`), `ClearObjectRAM`.
  The slot layout so far is in RAMMAP.
* **Ice Slasher's freeze** is traced: weapon 3 sets the object's timer at offset
  `$22` to 312 frames and does no damage; `CallObjectRoutine` counts it down.
  The weapon-hit path goes through `Func_00_1143`, the reader of `Data_00_11B8`,
  and subtracts the result from offset `$18` — which supports that table being
  weapon damage (still `[?]` until the lookup itself is traced).
* **Five deliberate hang traps** (`jr` to self) guard internal limits; one is
  never used. See UNUSED.md.
* Still provisional, with comments: `Func_00_252B` (retire dead objects),
  `25E9`, `262E`, `2657`, `26C0` (spawn list), `28E2` (scroll window), `2A1E`,
  `2A25`, `2A3E`, `2A56` (collision pass), `2B99`/`2BA0`, `2BC7`.
* `tools/srcgen.py`: byte-scan "callers" inside source are now believed only if
  linear decoding from the nearest symbol lands on them, and the audio banks no
  longer count. That removed four false labels in this range.

### Step 2.3 — `$16CB`–`$1758`, `$186F`–`$1AE3`, `$1AFC`–`$1B6B` (2026-10-04)

* **All three gaps are source**, byte-identical on the first build. Bank `$00`
  57% → 63%; whole ROM **19.51%**.
* **Unused arithmetic library at `$16CB`** (`Mul16x16`, `Div16`, `Div32By16`,
  `RandomBelow`). Nothing in the ROM calls, jumps to or points at any of them.
  Each was checked by simulating its exact instruction semantics against Python
  arithmetic on 20,000 random inputs: the multiply and 16-bit divide are correct;
  `Div32By16` drops the bit shifted out of B each round, so ~89% of results are
  wrong once the divisor exceeds `$8000`; `RandomBelow` never returns for A = 0.
  Listed in `docs/UNUSED.md`.
* **VRAM-safe routines** `MemsetVRAM`, `WriteVRAMByte`, `CopyVRAM` (+ the
  `CopyVRAMHBlank` path bank `$01` calls directly, and 3/2/1-byte burst helpers).
  With the LCD on they write only at the start of each HBlank — one burst per
  scanline and nothing during VBlank — so blanking a 1 KB map takes about seven
  frames. `MemsetVRAM` and `WriteVRAMByte` each have a second, uncalled entry
  that skips the LCD check.
* `GetTablePointer` (`$1968`, HL = word at HL + 2A; stub `$015F`, nine callers) and
  its unused byte twin `GetTableByte`.
* **Line-stepper** `LineStepInit` / `LineStep` (`$1973` / `$19B5`, stubs `$0189` /
  `$018C`): Bresenham-style stepping from (L,H) toward (E,D), C pixels per step,
  returning NZ when a coordinate wraps. State at `$D8AC`–`$D8B4` (`wLine*`). Banks
  `$03`, `$09`, `$0D` each contain **their own copy** of this code on the same RAM.
  The setup gets the direction wrong when the start coordinate is 0.
* **Screen loaders**, tied to the bank `$06` text groups: `LoadGameOverScreen`,
  `LoadPasswordScreen` (CallBank1Routine index 5), `LoadEndingScreen` (index 6),
  their shared `LoadTextScreenBase` (tiles + map blanked to the `$6C` space tile),
  `DrawTextList` / `DrawTextString` (the reader of the `screentext` format),
  `LoadTitleScreen` and `CopyTilemapRect` (the title logo). `PlayStage` also calls
  `LoadTitleScreen` on entry to every stage — probably for its tile blocks; `[?]`.
* `Func_00_1AFC` (CallBank1Routine index 3, stub `$019B`, bank `$01` `$617E`) loads
  a two-map layout of 20×9 tilemaps via `CopyTilemap20x9`; which screen it is
  remains open.

### Step 2.2 — `$0CDC`–`$167E` and the cartridge header (2026-10-03)

* **Header in source** (Will's request). `SECTION "Header"` at `$0100`: entry
  `nop`/`jp Start`, the logo, title `MEGAMAN`, DMG-only, cartridge type MBC1,
  256 KB ROM, no SRAM, non-Japanese, old licensee `$08` (Capcom), version 0. The
  values are named in `constants/cartridge.inc`. `rgbfix -f hg` now only fills the
  header and global checksums ($E4 / $C25B).
* **Whole range is source**, byte-identical. Bank `$00` 41% → 57%; whole ROM now **19.07%**.
* Named with `;[ok]`: `Start`, `Init` and its `.softReset` entry (ReadJoypad's
  soft-reset combo jumps there), `ClearRamCode`, `DisableLCD`, `DelayFrame`,
  `WaitForLY0`, `WaitForLYL`, `NegateDE`, `EnableLCDBG`, `EnableLCDOBJ`,
  `EnableLCD`, and bank `$01`'s `TitleScreen` ($1:60AF: title music `$2A`, 120
  frames of ignored input, then waits for Start).
* `HideAllSpritesAlt` ($166E) duplicates `HideAllSprites` ($2F83) and is followed
  by an unreachable `ret`.
* `BGTiles_0D0D`: five tiles loaded to `$8FB0` (tiles `$FB`–`$FF`), now
  `gfx/bg_tiles_0d0d.png`. Will reads them as background graphics; `Data_00_0D5D`
  holds five 5-byte records that place them. Purpose still `;[?]`.
* `Data_00_11B8`: ten 12-byte rows indexed by object class and `wCurrentWeapon`,
  with `$FF` meaning "keep the default". Probably the weapon damage table — `;[?]`
  until the caller is traced in Phase 5.
* **RAM hooks**: bank `$01` installs `jp $4140` at `$C0AA` (`wHookA`) and
  `jp $42AE` at `$C0AD` (`wHookB`); `StageFrameLoop` calls `wHookB` every frame.
* `$0D76` (a Start-button check) has no direct callers; how it is reached is open.
* `tools/srcgen.py --trace` undershoots where code is reached only from banks still
  under INCBIN, so the policy is: decode as code, and mark as data only what has
  been confirmed as data.

### Audio notes, the alternate Fire Man stage, and `QueueSound` (2026-10-03)

Prompted by Will's notes on unused content. New `docs/UNUSED.md` keeps a register.

* **The unused eighth stage slot is the alternate Fire Man stage.** Its record
  points at real data in bank `$08` (`$22F67`–`$23828`), which shares 23.4% of its
  8-byte sequences with Fire Man's stage against 1–3% for every other stage,
  including a 76-byte identical run. Will had reported the alternate stage; this
  locates it. Rendering it is Phase 4.
* **`Func_00_03CD` is `QueueSound`.** It doesn't play anything: it appends the ID to
  the new `wSoundQueue` (`$D920`, a count plus 20 entries). **An ID is the SoundTab
  index plus one**, resolved in whichever bank `wAudioBank` selects — confirmed by
  four independent cases. iimarckus's hand-written ID list in the comment has been
  replaced by a table generated from Will's two SoundTabs, covering every ID the
  ROM queues with a literal.
* **`WilyUnk` and `UnkTheme`** — neither pointer slot is referenced anywhere and
  neither ID is ever queued by a literal. Consistent with Will's "unused".
* **`SFX_Empty1`/`SFX_Empty2` are queued by the game** (IDs `$13`, `$14`, from object
  code in banks `$01`/`$03`) and each carries one track — not empty.
* **No composite sounds at the call sites.** Nothing queues two sounds back-to-back,
  so any composition is inside the sound data or the driver.

### Phase 2.1 — the font, and the game's main flow (2026-10-03)

Coverage 17.07% → **17.88%**; bank `$00` 26% → **40.8%**.

**Graphics now build from PNGs.** `$041E`–`$05BD` is a 26-tile A–Z font and
`$05BE`–`$05FD` four tiles of a health bar at four fill levels (identified by Will).
`LoadFontTiles` (`$03C3`) copies all 30 to VRAM in one go. Both are now
`gfx/font.png` and `gfx/health_bar.png`; `build.sh` and `make.bat` run `rgbgfx` over
`gfx/*.png` before assembling, and the round trip is exact with rgbgfx's default
grayscale mapping. `tools/gfx.py` extracts tiles to PNG.

**`tools/srcgen.py`** turns a ROM range into assemble-ready source: labels for
every branch target, symbols from `mmwr.sym` substituted into operands, hardware
register names, `bankswitch` collapsed to the macro, and `--data`/`--words` ranges.
Getting it right took three corrections, all caught by the build:

* byte-scan "callers" that land mid-instruction created labels that were never
  emitted — labels are now only placed on instruction boundaries;
* `call $15EA` came out as `call OAMDMARoutineEnd`, because an end-marker label
  shares that address — `…End` labels are never used as operands now;
* a byte-scan caller is only believed if its target follows a `ret`/`jp`/`jr`, or if
  the caller sits in already-disassembled code. One false global (`$0B21`) still
  got through, from a `dw` table that looks like a `jp`, and was folded back by hand.

**`$0855`–`$0CC9` is the main game flow**, 1,140 bytes, all source now:

* `NewGame` — buster unlocked, progress cleared, title screen, then the loop.
* Stage choice: robot master select, or the Wily castle once all four bosses are
  down (`wWilyStageSet`), with Wily progress tracked in `$DF96`.
* `PlayStage` — palettes, interrupts, stage music, then `StageFrameLoop`, which
  branches every frame on the new **`wStageState`** (`$CCFD`): 0 playing, 1 boss room
  entered (switch to `Audio1_Boss`), 2 boss beaten (`BossDefeated` plays
  `Audio1_Victory` and sets the new **`wVictoryTimer`** to `$01E0` — eight seconds),
  3 counting that down. Then the boss is marked defeated and play returns to stage
  selection. Clearing the third Wily stage goes to bank `$0E` instead.
* `LoseLife`, `ResetGameState`, `RefillWeaponEnergy`, `FetchSongPointer`, and
  `CheckPasswordEntry` (`[?]` — the screen it runs is inferred to be the password
  screen, not traced).
* `call $DF80` in the frame loop calls into WRAM — another piece of RAM-resident
  code alongside the `$C0A4` block.

**`StageMusicTab` (`$09F5`) is the missing reader of `AudioSoundTabPtrs`**, closing
that Phase 1 question. It's indexed one-based from `StageMusicTab - 2`, the same
trick as `StageLoadTab`, and resolves through two more levels of pointers to bank
`$02`'s SoundTab: stages 1–4 → `CutMan`/`IceMan`/`ElecMan`/`FireMan`, the first two
Wily stages share `Wily1`, the third gets `Wily2`.

**Stage 8 is never selected.** Its music entry points at SoundTab 39 — one of the
`DoNotUse` labels that fall through into `Audio1_EndGameAlt` — and its
`StageLoadTab` record points at bank `$08` like the other Wily stages. But the Wily
branch only ever sets stages 1–3, and clearing stage 3 goes straight to the ending.
So there is a complete, wired-up fourth Wily slot that this code never reaches, and
the track Will catalogued as the alternate end-game theme is the music assigned to
it.

### Phase 1.5 — the text (2026-10-03). Phase 1 complete.

Coverage 16.93% → **17.07%**.

* **`constants/charmap.inc`** declares a named `screen` charmap — tile index =
  ASCII + `$60`, space `$6C`, `©` at `$A0` — and leaves the default `main` charmap as
  plain ASCII, because the game uses both encodings and RGBDS charmaps are global.
  Source switches with `SETCHARMAP screen` / `SETCHARMAP main` around the strings.
  The UTF-8 `©` goes through the charmap cleanly; the build was byte-identical on
  the first attempt.
* **Bank `$06`'s four string groups are source**, as `screentext <dest>, "<text>"`
  macros with `endscreentext` for the null-destination terminator. Destinations
  read as `TILEMAP0 + $105` rather than raw hex. The four groups are
  `PasswordText`, `EndingText`, `GameOverText` and `TitleScreenText`, reached through
  named pointer slots at `$18034`–`$1803B`, which are themselves slots 3-6 of the
  bank's top-level pointer table.
* **There is no other text in the game.** A sweep of the entire ROM in both
  encodings, with and without the record framing, finds only those 19 strings, the
  bank `$00` stage-name table (already source, in plain ASCII) and the cartridge
  header title. Everything else that matched was a run of sequential tile indices —
  `ABCDEFG…` for tilemaps, and reversed runs like `PONMTSRQ…` for mirrored sprites.
  So the open question "where is the ending text" has an answer: the ending's only
  text is `EndingText` — `THANK YOU / FOR PLAYING / PRESENTED BY / CAPCOM`. If there
  is a staff roll, it is drawn as graphics, not stored as text.
* Bonus, from splitting that `INCBIN`: the two four-byte records at `$1802A` are
  `(length, source)` pairs — `$06E0` bytes from `$4227`, then `$0400` from `$4907` —
  and `$4227 + $06E0 = $4907`, so they describe one contiguous run starting at
  `$18227`. Almost certainly screen tile graphics. Left as `Data_06_402A` /
  `Data_06_402E` with `[?]` for Phase 3. And the record at `$18032` points at
  `$18149`, three bytes *before* iimarckus's `TitleScreenData` label, so that label
  is probably three bytes late.
* **`TypeBossName` (`$2097`)** named. Bank `$01`'s boss-intro loop at `$6294` calls
  it once per frame for 120 frames, and it draws the letter whose index is the frame
  count — so the robot master's name types itself out over the first nine frames.
  The same loop then increments `wSelectedStage`, which is the zero-to-one-based
  conversion step 1.4 relied on — now seen directly rather than inferred.
* **`wTileCopyCount` was the wrong name**, and is now `wScreenCounter`. Tracing
  `TypeBossName` showed `$CCF9` is the boss-intro frame counter and letter index;
  it is also the stage-select zoom sentinel and, in one routine, a tile-copy loop
  counter. A general counter that several screens reuse. The old name described the
  least important of its three uses. It stays `[?]`.

**Phase 1 is complete.** Every computed bank switch is explained, the RAM and
hardware names are in, the version picture is clear, and all the game's text is
readable source. Phase 2 — working through bank `$00` — is next.

### Phase 1.4 — the computed bank tables (2026-10-02)

Coverage 16.74% → **16.93%**. Both tables are now source rather than `INCBIN`.

Of the 117 `bankswitch` sites, 26 take their value from somewhere other than an
immediately preceding literal, and they sort into exactly four mechanisms:

| Mechanism | Sites | Banks it can select |
|---|---:|---|
| `ld a,[wAudioBank]` | 6 | `$02`, `$0A` |
| `pop af` (restore a saved bank) | 7 | whatever was saved |
| `ld a,[wStageBank]` | 10 | `$05`, `$08`, `$0E` |
| `ld a,[hl]` at `OBJ_BANK` | 2 | `$03`, `$09`, `$0D`, `$01` |

**`StageLoadTab` (`$2F93`)** — eight four-byte records, `dw <ROM0 pointer slot>` +
`db <bank>` + an unused `$00`. `LoadStage` (`$3000`, also now source) pages in bank
`$05`, indexes the table, and stashes the record's bank in `wStageBank` (`$DF9B`,
newly named) before paging it in. The four robot master stages point at bank `$05`,
the four Wily stages at bank `$08`, chosen by `wWilyStageSet` (`$DFC8`) adding 4 to
the index. The loader then follows two levels of indirection — a ROM0 pointer slot
in the `$0305`-`$03C1` table, then a pointer inside the stage's bank — and copies
four header bytes out as `wStageParams`.

The table is indexed **one-based**: `LoadStage` loads HL with `$2F8F`, four bytes
early, so index 1 lands on the first record. That bias points into the
`dec b / jr nz / ret` tail of `HideAllSprites`, not into padding, which is why the
table looked like it started with a garbage record (`bank $FB`) on the first read.
`wSelectedStage` is zero-based on the stage-select screen and incremented by bank
`$01` at `$062BA` before the load, which reconciles the two.

**`ObjectTypeTab` (`$3693`)** — 56 four-byte records, `dw <handler>` + `db <bank>` +
an unused `$00`. Each live object carries its handler's bank in its own record at
`OBJ_BANK` (`+$1B`); the far-call sites at `$28A3` and `$2A5B` read it back and page
it in before jumping to `OBJ_HANDLER` (`+$15`) offset by `OBJ_HANDLER_IDX` (`+$17`)
× 2.

The clincher: every handler address in that table is a slot in the target bank's
entry table, and **every slot in banks `$03`, `$09` and `$0D` is referenced exactly
once, in order** — 22, 24 and 9, which is precisely how many `jp` entries each of
those banks has (measured independently back in Phase 0). The 56th record points at
a lone bank `$01` address. Those three banks exist to hold object behaviour code and
this table is their complete index.

Also added `constants/objects.inc` with the four object-record offsets traced so
far, and `HideAllSprites` (`$2F83`) as source.

**Mistakes worth recording.** Two, both caught by the build:

* I inserted a new WRAM section above `wRNGSeed`, which had been following `wEnergy`
  implicitly, and silently relocated it from `$DFAE` to `$DFC9`. `./build.sh` caught
  it; `ram/wram.asm` now pins the RNG to its own section, and the comment there says
  why.
* `$0072F` looked like a 15-entry far-pointer table in the heuristic scan. It is a
  repeated `1c 77 09 1a` fill pattern — a false positive, discarded.

**Open:** nothing has been traced *writing* `OBJ_BANK`. Both sites that touch it only
read, so the field is filled at spawn by a route that does not use the
`ld a,$1B / add a,c` idiom — probably a bulk copy from a template. Finding the spawn
path should also give the 56 object types their names.

### Version notes and corrected string table (2026-09-22)

Will supplied first-hand notes on the four regional versions; `docs/VERSIONS.md`
now holds them, separating what was checked here from what was not.

His account of the title screens is **confirmed**, by walking each version's bank
`$06` string block:

* **(U)** carries the credits on the title screen itself — `@CAPCOM CO.,LTD.1991`,
  `@CAPCOM U.S.A.,` / `INC.1991`, `LICENSED BY NINTENDO`.
* **(E)**, published by Nintendo, has **no Capcom USA line anywhere** and no
  title-screen credits. Its block instead opens with six strings the other versions
  do not have — `@ 1991 CAPCOM`, `MEGAMAN IS`, `A TRADEMARK`, `OF CAPCOM`,
  `LICENSED TO`, `NINTENDO FROM`, `CAPCOM` — the separate splash screen he
  described. The block then stops after `PASS WORD` where (U) continues.
* **(J)** has a single `@CAPCOM 1991`, lacks `GAME END` and `START BUTTON`
  entirely, and sends its menu strings to different tilemap positions, so those
  screens are laid out differently rather than merely translated.

Not verified, because no dump was available: the Japanese prototype's palette and
music differences, and its unimplemented boss doors. The last of those is recorded
as something to watch for in Phase 4.1 — if the prototype's layouts encode
side-by-side doors, the final stage data may still carry vestigial fields for them.

Two corrections came out of this:

* `tools/strings.py` now walks the `dw`/string/`$00` records properly, and its
  output replaced the transcript in `docs/ROMMAP.md`, which I had done by eye and
  got wrong in several places — `FOR PLAYING` is at `$9884` not `$9824`,
  `START BUTTON` at `$99A3` not `$9943`, and `ERROR !!` has a space in it.
* The tool can emit RGBDS source with `--asm`, which is most of step 1.5.

### Phase 1.3 — hardware names, and the regional-version question (2026-09-22)

Coverage 16.69% → **16.74%**.

**Data Crystal's map is the European ROM.** Will suspected this and he was right.
Ten of its ten code addresses land exactly in `Megaman - Dr. Wily's Revenge (E)
[!].gb`. The step-1.1 conclusion that its addresses were "unreliable, and not by a
constant offset" was wrong: the varying offsets are the genuine (U)↔(E) divergence.
`docs/ROMMAP.md` has been rewritten, and the wrong conclusion is flagged there
rather than quietly deleted.

Comparing the three dumps (U, E, and Rockman World (J)) gave something better than
a correction:

* **Eleven of the sixteen banks are byte-identical across all three versions** —
  `$02`, `$03`, `$07`, `$08`, `$09`, `$0A`, `$0B`, `$0C`, `$0D`, `$0E`, `$0F`. Only
  `$00`, `$01`, `$06` and small patches of `$04`/`$05` differ. So documentation
  about those eleven banks needs no address correction at all, and the audio
  disassembly applies to every region unchanged.
* (J) is the more distant relative: 1,657 differing bytes in bank `$04` and 681 in
  `$05`, against (U)-vs-(E)'s 3 and 4.
* Observed (U)−(E) offsets: bank `$00` −2 from `$0855` to `$20E1`; bank `$01` 0 up
  to `$5766` then −30; everything else 0 at every point checked.

**`tools/findbytes.py`** operationalises the rule — give it a byte pattern from
whatever source you are reading (with `??` wildcards if needed) and it reports where
that pattern really is, in our ROM and in any other dumps you point it at.

Step 1.3 proper:

* All `$FFxx` register literals in the source now use `hardware.inc` names.
  `constants/memory.inc` adds `VRAM_TILES0/1/2`, `OAMRAM` and `STACK_TOP`, all
  guarded so a future hardware.inc update cannot collide. Tilemap addresses are now
  `TILEMAP0 + $0CD` rather than `$98CD`.
* `constants/joypad.inc` adds `PADF_*` and `P1F_GET_*`; this copy of hardware.inc
  (5.3.0) has neither those nor the `_VRAM*` area constants.
* **`ReadJoypad` (`$157D`)** disassembled. Reads the d-pad twice and the buttons
  eight times, OR-ing the button reads so a bouncing contact reads as not-pressed;
  `cpl` to active-high; d-pad swapped into the high nibble. `xor`/`and` against the
  previous state gives the newly-pressed edge. Then two things worth knowing: **A +
  B + Select + Start held together is a soft reset** (jumps to `$0605`), and the
  routine **stirs the RNG with the held input**, folding it together with
  `wVBlankCount` into `wRNGSeed`. Player input as an entropy source.
* **`InstallOAMDMA` (`$15D2`)** and **`OAMDMARoutine` (`$15E0`)** disassembled; the
  ten HRAM bytes are now source, with the 40-iteration wait written as `ld a,40`.
* A useful false positive: `ld hl,$FFF2` at `$23C7` is not an HRAM address, it is
  −14 being added to DE. `tools/ramrefs.py` counted it as an HRAM reference. The
  source now says `ld hl,-14`.

One mistake worth recording: the first attempt at `ReadJoypad` wrote the button
read-back loop as `REPT 5` when the ROM has six reads. `./build.sh` caught it
immediately — everything after `$159A` shifted by two bytes.

### Phase 1.2 — RAM map (2026-09-22)

Coverage 16.66% → **16.69%**. The gain is small because this step's output is
names, not bytes; the 55 bytes came from two routines that had to be disassembled
to justify a RAM label.

* **`tools/ramrefs.py`** tallies every RAM address the ROM touches, scanning for
  `ld [nn],a`, `ld a,[nn]`, `ld hl/de/bc,nn` and `ldh`. Its one idea worth keeping:
  each hit is classified `code` or `blob` depending on whether its ROM offset is
  inside real source or still inside an `INCBIN`. Raw counts across the whole ROM
  are mostly noise — bank `$04`'s graphics alone throw hundreds of false
  `ld hl,$Cxxx` hits — so the `code` subset is the only trustworthy part.
* **120 addresses are reachable from disassembled non-audio code. 44 are now
  named** in `ram/wram.asm` and `ram/hram.asm`; the remaining 76 are tabulated with
  reference counts in `docs/RAMMAP.md`.
* **157 numeric literals became labels** across `banks/bank00.asm` and
  `banks/bank01.asm`. 33 and 41 raw `$Cxxx`/`$Dxxx`/`$FFxx` literals remain in
  those two files respectively, all of them addresses we cannot yet justify a name
  for.
* **No `wUnknown_XXXX` placeholders were created.** Replacing `$CCF7` with
  `wUnknown_CCF7` adds a name but no knowledge, and it would make the next reader
  think the address had been looked at. The plan called for them; the table in
  `docs/RAMMAP.md` is the honest form of the same information.

What the VBlank handler at `$0675` gave up, all of it plainly readable once the
labels were in: `wFrameCounter` (every frame), `wVBlankCount` (16-bit, only on
frames that do work), `wVBlankBusy` as the re-entrancy guard, `wVBlankDone` as the
flag the main loop waits on, and the four LCD shadows `wShadowSCX`, `wShadowSCY`,
`wShadowLCDC`, `wShadowBGP`. It also showed the audio tick being called by paging
the bank manually and `call $400F`, rather than through the `AudioPlay` stub named
in step 1.1 — the two paths coexist.

Other findings:

* **`$C0A4`–`$C0FF` is a 92-byte block of RAM that the game executes.**
  `Func_00_066A` memsets it to `$C9` (`ret`), the LCDC/STAT vector at `$0048` is
  `jp $C0A4`, and `CallBank1Routine` assembles a `jp` at `$C0D0` inside it. Banks
  `$0B`/`$0E` also copy a 23-byte table to `$C0B0`, which overlaps — unresolved,
  and flagged `[?]` in `ram/wram.asm`.
* **The stage-select screen is now legible.** `wSelectedStage`, `wBossesDefeated`
  (bits 3/0/1/2 gate the four portraits), the four `wStageSelectPos` X/Y pairs, the
  animation timer/phase/frame, and the metasprite scratch block `wMetaspriteBaseX`
  … `wMetaspriteRows` used by the block-drawing routine at `$1C6D`.
* **`wCurrentWeapon` (`$DFA0`)** — bank `$01`'s refill code adds it to the
  `wEnergy` base to pick which meter to top up, which is what names it.
* **Disassembled `FuncMemset` (`$1694`)** — writes A to `[HL]` then falls into
  `FuncFill` with DE = HL+1, dragging the value along the run. 19 call sites. And
  **`Mul8x8` (`$169F`)**, a fully unrolled 8×8→16 multiply, written back as a
  `REPT` that assembles to the identical bytes.

### Phase 1.1 — audio interface, label rename, Data Crystal audit (2026-09-22)

Coverage is unchanged at 16.66%: this session converted no new `INCBIN` bytes. What
it produced was understanding, and a source tree that is now this project's own work
rather than a copy of someone else's labels.

* **Renamed every inherited label.** 386 labels moved from the iimarckus skeleton's
  `FunctionXXXX`/`PointerXXXXX` shapes to bank-qualified `Func_BB_AAAA`,
  `Ptr_BB_AAAA`, `Data_BB_AAAA`, `Entry_BB_AAAA` — 540 replacements, driven from the
  symbol table so a label's bank and address are always right. A further 123
  replacements reworded the ~60 descriptive guesses into our own terms.
* **Added confidence tags.** Every descriptive label now carries `;[ok]`, `;[dc]` or
  `;[?]` — see `docs/CONVENTIONS.md`. Current census: 3 `[ok]`, 30 `[dc]`, 11 `[?]`.
* **Identified the Mega Buster shot graphics.** iimarckus's `UnknownBulletGFX` sits in
  slot 3 of bank `$04`'s pointer table, and slots 3–13 of that table are the weapons
  in exactly the order of the unlock bits at `$DFA1`/`$DFA2`. Slot 3 is the Mega
  Buster. Renamed `MegaBusterShot`.
* **Step 1.1 done.** The seven audio stubs at `$0236`–`$024A` are named after the
  entries they reach in `audio/bank02.asm`; `Func_00_02AD` is now `FarCallAudio` with
  its mechanism written out; `Func_00_01F4` is `CallBank1Routine`.
  `ram/wram.asm` and `ram/hram.asm` name `wCurrentBank`, `wAudioBank`,
  `hFarCallA`–`hFarCallD` and `hBank1CallIndex`, and the `bankswitch` macro uses them.
* **The tail-call question is settled** — it was a false alarm. Callers `call` the
  3-byte stub, and the stub runs the `rst $08`; the return address the trampoline
  discards is the stub-internal one, not the caller's. These are ordinary calls that
  cross a bank boundary. Recorded in `docs/BANKS.md`.
* **Audited Data Crystal's ROM map** (supplied by Will) — `docs/ROMMAP.md`. Its
  descriptions are all correct; its addresses are not, and not by a single offset:
  bank `$00` entries are 2 bytes high, bank `$01` entries past `$5772` are 30 bytes
  high, bank `$05` and `$06` are exact. Their bank-end figures match our measurements
  for 14 of 16 banks. Two of their hex listings contain typos that reverse the
  meaning (`34`/`35`, `3D`/`3E`). Every claim has been re-derived by byte search.
* **Cracked the text encoding**, as a side effect of checking their "name enemies"
  entry. Screen text is tile index = ASCII + `$60`, space `$6C`, `$00` terminator,
  each string preceded by a little-endian BG tilemap destination. Bank `$00`'s name
  table at `$20CA` is plain ASCII. The whole bank `$06` string block decodes cleanly
  — transcribed in `docs/ROMMAP.md`. Step 1.5 is now extraction, not discovery.

**Open questions carried forward:**

* `AudioSoundTabPtrs` (`$024B`, 49 words) is an identity mapping onto the audio
  bank's `SoundTab`. Nothing has been traced reading it.
* `CallBank1Routine` builds a `jp` in WRAM at `$C0D0` rather than using a jump table.
  Noted for the Phase 6 efficiency tally.
* Bank `$05`: `$16AAD`–`$16F21` sits past the end of the stage data and before the
  padding, and nothing accounts for it.
* The ending text has not been located; it is probably in bank `$0E`.

### Phase 0.1 — foundation (2026-09-21)

* Confirmed the supplied ROM (`Megaman - Dr. Wily's Revenge (U) [!].gb`, 262144 bytes)
  is byte-identical to the `base1.gb` that iimarckus's disassembly expects
  (sha256 `33d163…`).
* Built RGBDS 0.9.4 from source — it is not packaged in Ubuntu. `tools/bootstrap-rgbds.sh`
  reproduces this in about a minute.
* Ported `1.s` from the iimarckus repo to modern RGBDS. Three mechanical
  incompatibilities, all from RGBDS 0.6's syntax break:
  1. `name: MACRO` → `MACRO name`
  2. labels declared without a trailing colon
  3. `ld [$FFxx], a` / `ld a, [$FFxx]` — old RGBDS silently folded these into the
     2-byte `ldh` form; current RGBDS emits the 3-byte `ld [n16]` form. 37 lines
     affected, and this was the whole cause of the initial size overflow.
  With those fixed, `1.s` reproduces the ROM byte for byte. It is a labelled
  skeleton rather than a real disassembly — 472 labels over 4.9 KB of assembly and
  189 KB of `INCBIN` — but it is a *verified* one, and it gave us the section
  layout for all 16 banks for free.
* Split it into `banks/bank00.asm` … `banks/bank0f.asm`.
* Imported Will's audio disassembly as `audio/bank02.asm` and `audio/bank0a.asm`
  (from `MM1A.ASM` / `MM1B.ASM`, bank numbers corrected from the standalone
  player's `$1`/`$2` to the real `$02`/`$0A`), with `RAM.INC` split into
  `constants/audio_ram_constants.inc` and `ram/audio_ram.asm`. **Both banks
  reproduce the original with zero differing bytes.** That alone took the project
  from 1.9% to 16.7% coverage.
* Wired the audio banks' `JumpRNG`/`JumpFill` calls to real ROM0 labels at `$0159`
  and `$0162`.
* Disassembled `FuncRNG` (`$1758`, 23 bytes) from Will's `FUNCTIONS.ASM` and, in
  the process, identified the 256-byte `RNGTable` at `$176F` that it indexes —
  the first region disassembled by this repo rather than inherited.
* Wrote `tools/coverage.py`, `tools/disasm.py` (a straight-line disassembler in
  RGBDS syntax) and `tools/roundtrip.sh`. `disasm.py` round-trips exactly on seven
  sampled ranges across banks `$00`, `$01`, `$02` and `$09`.
* Mapped the banking architecture — see `docs/BANKS.md`. The important findings:
  111 of 117 bank switches are in bank `$00`; bank `$01` is the resident default;
  `$DF9A` selects between the two audio banks; `rst $08` → `$02AD` is the audio
  far-call trampoline, with seven thunks at `$0236`–`$024A`; and every banked bank
  except `$01` and `$0F` opens with a `jp` or `dw` entry table.
* Bank `$0F` is entirely empty (16 KB of `$FF`).

**Not done / open questions carried forward:**

* Data Crystal's *ROM map* and *Text table* subpages both returned HTTP 403 and
  have not been read. Retry them in step 1.5.
* The audio far-call trampoline appears to have tail-call semantics (it discards
  the caller's return address). Confirm under an emulator before relying on it.
* Banks `$03`, `$08`, `$09`, `$0D` have no literal bank switch pointing at them;
  the table that reaches them is step 1.4.
