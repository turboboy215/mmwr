;Mega Man: Dr. Wily's Revenge disassembly - object type 26, Obj26
;Part of ROM bank $09 (step 5.2), included from banks/bank09.asm. Every section is
;pinned to its original address. Confidence tags: [ok] verified here, [dc]
;corroborated by Data Crystal, [?] guess.

SECTION "Obj26 (type 26)", ROMX[$50E8], BANK[$9]

;Object type 26: never placed; type 14's shot (Obj14SpawnShot points its
;$28/$29 at the thrower's $28 and runs Obj26Init). Moves 1.5 px a frame the way
;it faces; Time Stopper holds it. Off screen: removed, writing $A5 to the
;thrower's $28. Killed: removed without telling the thrower. There is no mode 0
;case.	;[ok]
Obj26Routine:	;$50E8
	ld a, b
	dec a
	jr z, Obj26Update
	dec a
	jr z, Func_09_50F2
	dec a
	jr z, Func_09_50F5

Func_09_50F2:	;$50F2
	ld b, $00
	ret

Func_09_50F5:	;$50F5
	jp ObjClearFreeze_09

Obj26Init:	;$50F8
	ld a, $24
	add a, c
	ld l, a
	ld d, [hl]
	ld a, $17
	add a, c
	ld l, a
	ld [hl], d
	ld a, $15
	add a, c
	ld l, a
	ld [hl], LOW(Data_09_514D)
	inc l
	ld [hl], HIGH(Data_09_514D)
	jr Func_09_512C

Obj26Update:	;$510D
	ld a, [wFreezeFlags]
	or a
	jp nz, Func_09_512C
	ld a, $24
	add a, c
	ld l, a
	ld a, [hl]
	ld de, $0180
	or a
	jr nz, .l5122
	ld de, $FE80
.l5122
	ld a, $0C
	add a, c
	ld l, a
	ld a, [hl]
	add a, e
	ld [hl+], a
	ld a, [hl]
	adc a, d
	ld [hl], a

Func_09_512C:	;$512C
	ld de, $D811
	ld a, $0D
	add a, c
	ld l, a
	ld a, [de]
	ld e, [hl]
	add a, [hl]
	ld d, a
	ld a, $0A
	add a, c
	ld l, a
	ld [hl], d
	call ObjCheckOnScreen_09
	ld a, b
	or a
	ret nz
	ld a, $28
	add a, c
	ld l, a
	ld e, [hl]
	inc l
	ld d, [hl]
	ld a, $A5
	ld [de], a
	ret

Data_09_514D:	;$514D
	dw Frame_5085, Frame_508F
