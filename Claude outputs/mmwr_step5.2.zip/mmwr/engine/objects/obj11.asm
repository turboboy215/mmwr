;Mega Man: Dr. Wily's Revenge disassembly - object type 11, Obj11
;Part of ROM bank $09 (step 5.2), included from banks/bank09.asm. Every section is
;pinned to its original address. Confidence tags: [ok] verified here, [dc]
;corroborated by Data Crystal, [?] guess.

SECTION "Obj11 (type 11)", ROMX[$4AE6], BANK[$9]

;Object type 11: placed seven times in Fire Man's stage, and thrown by type 12.
;Spawn: offset $2A = param bit 0 picks the mode. Mode 0 (placed): goes to Y 0
;and drops 2 px a frame to Y $B0, then starts again from the top, through walls.
;Mode 1 (thrown, with the velocity type 12 gives it): falls under gravity
;(ObjFallAndMove) and is removed at Y $90. Always faces Mega Man; two frames,
;15 frames each. Ice Slasher holds mode 0 still; mode 1 clears the freeze and
;keeps moving. Killed, or off screen sideways: removed.	;[ok]
Obj11Routine:	;$4AE6
	ld a, b
	or a
	jr z, Obj11Init
	dec a
	jr z, Obj11Update
	dec a
	jr z, Func_09_4AF3
	dec a
	jr z, Obj11Frozen

Func_09_4AF3:	;$4AF3
	ld b, $00
	ret

Obj11Frozen:	;$4AF6
	ld a, $2A
	add a, c
	ld l, a
	ld a, [hl]
	or a
	ret z
	call ObjClearFreeze_09
	jr Obj11Update

Func_09_4B02:	;$4B02
	jp Obj11CheckOffScreen

Obj11Init:	;$4B05
	ld a, $06
	add a, c
	ld l, a
	ld e, [hl]
	ld a, $2A
	add a, c
	ld l, a
	ld a, e
	and $01
	ld [hl], a
	ld a, $27
	add a, c
	ld l, a
	ld [hl], $00
	ld de, Data_09_4B82
	call AnimateObjectFacing_09
	ld b, $01
	ret

Obj11Update:	;$4B21
	ld a, [wFreezeFlags]
	or a
	jp nz, Func_09_4B02
	ld a, $2A
	add a, c
	ld l, a
	ld a, [hl]
	or a
	jp nz, Obj11UpdateThrown
	ld a, $27
	add a, c
	ld l, a
	ld a, [hl]
	or a
	jr nz, .l4B47
	ld a, $27
	add a, c
	ld l, a
	inc [hl]
	ld a, $0F
	add a, c
	ld l, a
	ld [hl], $00
	jp .l4B5A
.l4B47
	ld a, $0F
	add a, c
	ld l, a
	ld a, [hl]
	add a, $02
	ld [hl], a
	cp $B0
	jp c, .l4B5A
	ld a, $27
	add a, c
	ld l, a
	ld [hl], $00
.l4B5A
	call ObjFaceMegaMan_09
	ld de, Data_09_4B82
	call AnimateObjectFacing_09
	jp ObjCheckOnScreenX_09

Func_09_4B66:	;$4B66
	call ObjFaceMegaMan_09
	ld de, Data_09_4B82
	call AnimateObjectFacing_09

Obj11CheckOffScreen:	;$4B6F
	ld a, $0F
	add a, c
	ld l, a
	ld a, [hl]
	cp $90
	jp nc, Func_09_4AF3
	jp ObjCheckOnScreenX_09

Obj11UpdateThrown:	;$4B7C
	call ObjFallAndMove_09
	jp Func_09_4B66

Data_09_4B82:	;$4B82
	dw FrameTable_4B88
	db 15	;frames per step
	db $00, $02, $FF

FrameTable_4B88:	;$4B88
	dw Frame_4B90, Frame_4BA8, Frame_4B9C, Frame_4BB4

Frame_4B90:	;$4B90
	db $F8, $07, $F8, $07	;hitbox
	db $F8, $F8, $22	;dx, dy, 2x2
	db $00, $01, $02, $03
	db $80

Frame_4B9C:	;$4B9C
	db $F8, $07, $F8, $07	;hitbox
	db $F8, $F8, $22	;dx, dy, 2x2
	db $04, $05, $06, $07
	db $80

Frame_4BA8:	;$4BA8
	db $F8, $07, $F8, $07	;hitbox
	db $F8, $F8, $22	;dx, dy, 2x2
	db $81, $80, $83, $82
	db $80

Frame_4BB4:	;$4BB4
	db $F8, $07, $F8, $07	;hitbox
	db $F8, $F8, $22	;dx, dy, 2x2
	db $85, $84, $87, $86
	db $80
